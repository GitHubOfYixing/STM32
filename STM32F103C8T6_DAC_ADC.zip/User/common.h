#ifndef __COMMON_H__
#define __COMMON_H__

#include "stm32f10x.h" //�������е�ͷ�ļ�
#include "stdio.h"
#include "math.h"

#define ON  0
#define OFF 1
#define LED_PORT GPIOC
#define LED_PIN GPIO_Pin_13

#define LED(a)	if (a)	\
					GPIO_SetBits(LED_PORT,LED_PIN);\
					else		\
					GPIO_ResetBits(LED_PORT,LED_PIN)

void LED_Blink(void);				
void RCC_Configuration(void);
void GPIO_Configuration(void);
void TIM4_Configuration(u16 arr,u16 psc);
void USART_Configuration(void);
void DAC_Configuration(void);
void DAC_Set_Vol(float vol);
void ADC_Configuration(void);
double ADC_Check(void);
void NVIC_Configuration(void);
void Delay_us(u32 us);
void Delay_ms(u16 ms);

#endif
