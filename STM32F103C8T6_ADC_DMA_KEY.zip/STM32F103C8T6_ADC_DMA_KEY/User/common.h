#ifndef __COMMON_H__
#define __COMMON_H__

#include "stm32f10x.h" //�������е�ͷ�ļ�
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"
#include "stdarg.h" //�������벻������ͷ�ļ�

#define ON  0
#define OFF 1
#define LED_PORT GPIOB
#define LED_PIN GPIO_Pin_8

#define LED(a)	if (a)	\
					GPIO_SetBits(LED_PORT,LED_PIN);\
					else		\
					GPIO_ResetBits(LED_PORT,LED_PIN)

#define HMC_ADDR 0x78 //IIC�ӻ���ַ

#define  ADC_BUFF_LEN  50 //ADC�����С(ÿ��ͨ������50������)
extern uint32_t ADC_ConvertedValue[ADC_BUFF_LEN];		

extern u8 Key1_Value,Key2_Value,Key_Status;						

u8 Read_Key_Value(GPIO_TypeDef* GPIOx, u16 GPIO_Pin_x);					
void LED_Blink(void);				
void RCC_Configuration(void);
void GPIO_Configuration(void);
void TIM_Configuration(uint16_t arr, uint16_t psc);
void USART_Configuration(void);

void ADC_DMA1_Configuration(void);					
void ADC1_TIM2_Configuration(uint16_t arr, uint16_t psc);
void ADC1_Configuration(void);					
void ADC2_TIM4_Configuration(uint16_t arr, uint16_t psc);					
void ADC2_Configuration(void);
double Get_ADC_Value(u8 ADC_Channel);

void IIC_Configuration(void);
void HmcByteWrite(u8 addr, u8 dataValue);
u8 HmcByteRead(u8 addr);

void NVIC_Configuration(void);
void Delay_us(u32 us);
void Delay_ms(u16 ms);

#endif
