#ifndef __OLED_H__
#define __OLED_H__

#include "common.h"

#define OLED_MODE 0	
//OLEDģʽ����
//0:4����ģʽ
//1:����8080ģʽ
#define SIZE        8
#define XLevelL		  0x00
#define XLevelH		  0x10
#define Max_Column	128
#define Max_Row		  32
#define	Brightness	0xFF 
#define X_WIDTH 	  128
#define Y_WIDTH 	  32				

#define OLED_SCLK_Clr() GPIO_ResetBits(GPIOB, GPIO_Pin_6) //IIC1_SCL
#define OLED_SCLK_Set() GPIO_SetBits(GPIOB, GPIO_Pin_6)

#define OLED_SDIN_Clr() GPIO_ResetBits(GPIOB, GPIO_Pin_7) //IIC1_SDA
#define OLED_SDIN_Set() GPIO_SetBits(GPIOB, GPIO_Pin_7)

#define OLED_CMD 0x00	//д����
#define OLED_DATA 0x40	//д����	

void OLED_Set_Pos(unsigned char x, unsigned char y);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Clear(void);
void OLED_ShowChar(u8 x, u8 y, u8 chr, u8 Char_Size);
u32  OLED_Pow(u8 m, u8 n);
void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 size2);
void OLED_ShowString(u8 x, u8 y, u8 *chr, u8 Char_Size);
void OLED_ShowFloat(double num, u8 ndigits, u8 y);
void OLED_ShowOneChinese(u8 x, u8 y, u8 no);
void OLED_ShowChinese(u8 ch[], u8 len, u8 row);
void OLED_Init(void);
void OLED_Configuration(void);

#endif

